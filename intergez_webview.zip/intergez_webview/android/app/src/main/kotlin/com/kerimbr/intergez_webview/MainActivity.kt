package com.kerimbr.intergez_webview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
