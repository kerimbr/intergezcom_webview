

import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:webview_flutter/webview_flutter.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  WebViewController _webViewController;
  String url = "https://www.intergez.com/";

  Completer<WebViewController> _controller = Completer<WebViewController>();
  bool _loadingPageController=false;


  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {



    return SafeArea(
      child: Scaffold(
        body: FutureBuilder(
          future: _loadingPage(),
          builder: (context,snapshot){
            if(snapshot.hasData){
              return WillPopScope(
                onWillPop: () async{
                  if(await _webViewController.canGoBack()){
                    _webViewController.goBack();
                    return false;
                  }else{
                    return false;
                  }
                },
                child: SafeArea(
                  child: WebView(
                    onWebViewCreated: (WebViewController c){
                      _webViewController = c;
                      _controller.complete(c);
                    },

                    initialUrl: url,
                    javascriptMode: JavascriptMode.unrestricted,

                  ),
                ),
              );
            }else{
              return Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: Center(
                  child: CupertinoActivityIndicator(
                    radius: 22,
                  ),
                ),
              );
            }
          },
        ),
      ),
    );


  }


  Future<void> _yenile() async {
    await Future.delayed(Duration(seconds: 2));
    setState(() {});
  }

  Future<bool> _loadingPage() async{
    await Future.delayed(Duration(seconds: 1));
    _loadingPageController = true;
    return _loadingPageController;
  }

  Drawer _buildDrawer() {
    return Drawer(
      child: ListView(
        children: [
          Image.asset("assets/intergez_logo.png"),

        ],
      ),
    );
  }

}
