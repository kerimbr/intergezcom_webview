import 'package:flutter/material.dart';
import 'package:intergez_webview/splash_screen.dart';


void main(){
  runApp(InterGezApp());
}


class InterGezApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        accentColor: Colors.white
      ),
      home: SplassScreen(),
    );
  }
}
